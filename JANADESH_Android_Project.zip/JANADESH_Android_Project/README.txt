JANADESH Android project — Alpha 1.0

This is an Android WebView wrapper around the playable JANADESH HTML alpha.
It is an installable development project, NOT a compiled APK.

Build requirements:
- Android Studio
- JDK 17
- Android SDK Platform 35
- Gradle 8.9 or newer compatible with Android Gradle Plugin 8.7.3

Build:
1. Extract this ZIP.
2. Open the JANADESH_Android_Project folder in Android Studio.
3. Allow Gradle sync and install any requested Android SDK components.
4. Select Build > Build Bundle(s) / APK(s) > Build APK(s).
5. Debug APK output: app/build/outputs/apk/debug/app-debug.apk

Cloud build option:
Push this project to a GitHub repository on the main branch, or run the
"Build JANADESH APK" workflow manually under GitHub Actions. Download the
JANADESH-debug-apk artifact from the completed workflow.

Before a commercial Google Play release:
- Create a signed release AAB with a securely stored upload key.
- Add original icons, splash screen, privacy policy and support contact.
- Test on real Android devices, fix bugs, and complete Play Console declarations.
- The current game is an offline alpha prototype. It has simulated gameplay,
  limited content, and no verified cloud save or production QA.
